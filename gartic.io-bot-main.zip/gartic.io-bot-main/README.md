<div align="center">
  <h1 style="font-size: 3em;">Eleveda👋 - Goodbye👋</h1>
  <img src="https://i.imgur.com/oiEon0B.png" height="150">
  <p style="font-size: 1.5em;">This project has been created for educational purposes only. The project will end soon. We do not accept encouraging people to take the wrong path. This project was only created to explain how it works.</p>
</div>





-----------------------

# gartic.io-bot
[Bot Site](https://anonimbiri.github.io/gartic.io-bot/v2)


https://user-images.githubusercontent.com/83531197/236705132-e15cca36-d102-4efd-9b92-20275c1d3ec0.mp4


> **Note** The following operations are only for 1v, they are not necessary for 2v.

-----------------------
# Installation
## Requirements 
| Tampermonkey  | [Download](https://www.tampermonkey.net) |
| ----------- | ------- |

| Script        | [Download](https://github.com/anonimbiri/gartic.io-bot/raw/main/script/Gartic%20bot%20control.user.js) |
| ----------- | ------- |

## Installation Guide
**it's pretty simple to install**\
\
**Press the `download` button that appears on the screen.**\
\
**Congratulations, you downloaded**

    


-----------------------
## Disclaimer 
This project is for Educational Use only. We do not condone this software being used to gain an advantage against other people.

